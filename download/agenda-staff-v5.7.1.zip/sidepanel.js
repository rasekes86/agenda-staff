// ============================================
// AGENDA STAFF v5.7.1 - ICONO ROJO FIX, NAVEGACIÓN DÍAS PASADOS
// ============================================

const SUPABASE_URL = 'https://iugutcsukxkxlgpkmzxt.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml1Z3V0Y3N1a3hreGxncGttenh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzc5OTExMjksImV4cCI6MjA1MzU2NzEyOX0.PpolAzqqXNBOhRlUVzplqkKeGQxzfed4gH377CidVJE';

// State
let currentUser = null;
let session = null;
let events = {};
let collapsed = new Set();
let manuallyExpanded = new Set(); // Days manually expanded by user
let expandedEvents = new Set();
let editingId = null;
let dragId = null;
let dragDate = null;
let calDate = new Date();
let viewStartDate = new Date();
const VISIBLE_DAYS = 30;

// Notification settings
let notificationSettings = {
  enabled: true,
  minutesBefore: 5,
  sound: 'bell'
};

// Current reminder banner
let currentReminder = null;

// PDF state
let pdfImages = [];
let pdfOrientation = 'portrait';
let mergePdfs = [];
let splitPdfFile = null;

// DOM
const $ = id => document.getElementById(id);
const daysList = $('daysList');
const modalOverlay = $('modalOverlay');
const toast = $('toast');

// ============================================
// AUTHENTICATION
// ============================================

async function checkSession() {
  try {
    const stored = await chrome.storage.local.get(['session', 'user']);
    
    if (stored.session && stored.user) {
      const expiresAt = stored.session.expires_at;
      const now = Math.floor(Date.now() / 1000);
      const isExpired = expiresAt && (expiresAt - now < 300);
      
      if (isExpired && stored.session.refresh_token) {
        const refreshed = await refreshSession(stored.session.refresh_token);
        if (refreshed) {
          session = stored.session;
          currentUser = stored.user;
          showMainScreen();
          return;
        } else {
          await clearSession();
          showAuthScreen();
          return;
        }
      }
      
      const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${stored.session.access_token}`
        }
      });
      
      if (res.ok) {
        session = stored.session;
        currentUser = stored.user;
        showMainScreen();
      } else {
        if (stored.session.refresh_token) {
          const refreshed = await refreshSession(stored.session.refresh_token);
          if (refreshed) {
            const newStored = await chrome.storage.local.get(['session', 'user']);
            session = newStored.session;
            currentUser = newStored.user;
            showMainScreen();
            return;
          }
        }
        await clearSession();
        showAuthScreen();
      }
    } else {
      showAuthScreen();
    }
  } catch (err) {
    console.error('Session check error:', err);
    showAuthScreen();
  }
}

async function refreshSession(refreshToken) {
  try {
    console.log('Refreshing session...');
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ refresh_token: refreshToken })
    });
    
    if (!res.ok) {
      console.log('Refresh failed:', res.status);
      return false;
    }
    
    const data = await res.json();
    
    await chrome.storage.local.set({
      session: data,
      user: {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata?.name || data.user.email.split('@')[0]
      }
    });
    
    console.log('Session refreshed successfully');
    return true;
  } catch (err) {
    console.error('Refresh error:', err);
    return false;
  }
}

async function saveSession(sessionData, userData) {
  await chrome.storage.local.set({
    session: sessionData,
    user: userData
  });
}

async function clearSession() {
  await chrome.storage.local.remove(['session', 'user']);
  session = null;
  currentUser = null;
}

function showAuthScreen() {
  $('authScreen').style.display = 'flex';
  $('mainScreen').style.display = 'none';
}

async function showMainScreen() {
  $('authScreen').style.display = 'none';
  $('mainScreen').style.display = 'flex';
  
  viewStartDate = new Date();
  viewStartDate.setHours(0, 0, 0, 0);
  
  if (currentUser) {
    $('userName').textContent = currentUser.name || 'Usuario';
    $('userEmail').textContent = currentUser.email || '';
    $('userAvatar').textContent = (currentUser.name || currentUser.email || 'U')[0].toUpperCase();
  }
  
  await loadNotificationSettings();
  
  try {
    await chrome.runtime.sendMessage({ type: 'START_NOTIFICATION_CHECK' });
  } catch (err) {
    console.log('Could not start notification check:', err);
  }
  
  loadEvents();
}

async function loadNotificationSettings() {
  try {
    const stored = await chrome.storage.local.get(['notificationSettings']);
    if (stored.notificationSettings) {
      notificationSettings = { ...notificationSettings, ...stored.notificationSettings };
    }
    updateNotificationUI();
  } catch (err) {
    console.error('Error loading notification settings:', err);
  }
}

function updateNotificationUI() {
  const toggle = $('notifToggle');
  const minutesSelect = $('notifMinutes');
  const soundSelect = $('notifSound');
  
  if (toggle) toggle.checked = notificationSettings.enabled;
  if (minutesSelect) minutesSelect.value = notificationSettings.minutesBefore;
  if (soundSelect) soundSelect.value = notificationSettings.sound;
}

async function saveNotificationSettings() {
  notificationSettings = {
    enabled: $('notifToggle').checked,
    minutesBefore: parseInt($('notifMinutes').value),
    sound: $('notifSound').value
  };
  
  await chrome.storage.local.set({ notificationSettings });
  scheduleNotifications();
  showToast('Configuración guardada');
}

// Login
async function handleLogin(e) {
  e.preventDefault();
  
  const email = $('loginEmail').value.trim();
  const password = $('loginPassword').value;
  const errorEl = $('loginError');
  const btn = $('btnLogin');
  
  if (!email || !password) {
    showAuthError(errorEl, 'Completa todos los campos');
    return;
  }
  
  btn.disabled = true;
  btn.querySelector('.btn-text').textContent = 'Entrando...';
  btn.querySelector('.btn-loader').style.display = 'block';
  errorEl.classList.remove('show');
  
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password })
    });
    
    const data = await res.json();
    
    if (!res.ok) {
      throw new Error(data.error_description || data.message || 'Error al iniciar sesión');
    }
    
    session = data;
    currentUser = {
      id: data.user.id,
      email: data.user.email,
      name: data.user.user_metadata?.name || data.user.email.split('@')[0]
    };
    
    await saveSession(session, currentUser);
    showMainScreen();
    
  } catch (err) {
    showAuthError(errorEl, err.message);
  } finally {
    btn.disabled = false;
    btn.querySelector('.btn-text').textContent = 'Entrar';
    btn.querySelector('.btn-loader').style.display = 'none';
  }
}

// Register
async function handleRegister(e) {
  e.preventDefault();
  
  const name = $('registerName').value.trim();
  const email = $('registerEmail').value.trim();
  const password = $('registerPassword').value;
  const errorEl = $('registerError');
  const btn = $('btnRegister');
  
  if (!name || !email || !password) {
    showAuthError(errorEl, 'Completa todos los campos');
    return;
  }
  
  if (password.length < 6) {
    showAuthError(errorEl, 'La contraseña debe tener al menos 6 caracteres');
    return;
  }
  
  btn.disabled = true;
  btn.querySelector('.btn-text').textContent = 'Creando cuenta...';
  btn.querySelector('.btn-loader').style.display = 'block';
  errorEl.classList.remove('show');
  
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        email, 
        password,
        data: { name }
      })
    });
    
    const data = await res.json();
    
    if (!res.ok) {
      if (data.message?.includes('already registered')) {
        throw new Error('Este email ya está registrado');
      }
      throw new Error(data.error_description || data.message || 'Error al registrar');
    }
    
    if (data.session && data.user) {
      session = data.session;
      currentUser = {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata?.name || name
      };
      
      await saveSession(session, currentUser);
      showMainScreen();
      showToast('¡Cuenta creada correctamente!');
    } else if (data.user) {
      showAuthError(errorEl, '✓ Cuenta creada. Revisa tu email para confirmarla y luego inicia sesión.');
      setTimeout(() => {
        document.querySelector('[data-tab="login"]').click();
        $('loginEmail').value = email;
      }, 2000);
    } else {
      throw new Error('Respuesta inesperada del servidor');
    }
    
  } catch (err) {
    showAuthError(errorEl, err.message);
  } finally {
    btn.disabled = false;
    btn.querySelector('.btn-text').textContent = 'Crear Cuenta';
    btn.querySelector('.btn-loader').style.display = 'none';
  }
}

// Logout
async function handleLogout() {
  try {
    if (session?.access_token) {
      await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
        method: 'POST',
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${session.access_token}`
        }
      });
    }
  } catch (err) {
    console.log('Logout error:', err);
  }
  
  await clearSession();
  events = {};
  showAuthScreen();
  $('userDropdown').classList.remove('show');
}

function showAuthError(el, msg) {
  el.textContent = msg;
  el.classList.add('show');
}

// ============================================
// SUPABASE API WITH AUTH
// ============================================

async function api(method, body, query = '') {
  if (!session || !session.access_token) {
    const stored = await chrome.storage.local.get(['session']);
    if (stored.session && stored.session.access_token) {
      session = stored.session;
    } else {
      throw new Error('No hay sesión activa. Por favor, inicia sesión de nuevo.');
    }
  }
  
  const url = `${SUPABASE_URL}/rest/v1/calendar_events${query}`;
  const opts = {
    method,
    headers: {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation'
    }
  };
  if (body) opts.body = JSON.stringify(body);
  
  console.log('API Call:', method, url, body ? JSON.stringify(body) : 'no body');
  
  const res = await fetch(url, opts);
  console.log('API Response:', res.status, res.statusText);
  
  if (!res.ok) {
    const errText = await res.text();
    console.error('API Error:', errText);
    if (res.status === 401 || res.status === 403) {
      if (session.refresh_token) {
        const refreshed = await refreshSession(session.refresh_token);
        if (refreshed) {
          const newStored = await chrome.storage.local.get(['session']);
          session = newStored.session;
          opts.headers.Authorization = `Bearer ${session.access_token}`;
          const retryRes = await fetch(url, opts);
          if (retryRes.ok) {
            if (method === 'DELETE') return {};
            return retryRes.json();
          }
        }
      }
      await handleLogout();
      throw new Error('Sesión expirada. Por favor, inicia sesión de nuevo.');
    }
    throw new Error(errText || `Error ${res.status}: ${res.statusText}`);
  }
  if (method === 'DELETE') return {};
  return res.json();
}

// ============================================
// INIT
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  console.log('AGENDA STAFF v5.6.0 iniciado...');
  checkSession();
  setupListeners();
});

// Event Listeners
function setupListeners() {
  // Auth tabs
  document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      if (tab.dataset.tab === 'login') {
        $('loginForm').style.display = 'block';
        $('registerForm').style.display = 'none';
      } else {
        $('loginForm').style.display = 'none';
        $('registerForm').style.display = 'block';
      }
    });
  });
  
  // Auth forms
  $('loginForm').addEventListener('submit', handleLogin);
  $('registerForm').addEventListener('submit', handleRegister);
  
  // User menu
  $('btnUser').addEventListener('click', (e) => {
    e.stopPropagation();
    $('userDropdown').classList.toggle('show');
  });
  
  document.addEventListener('click', () => {
    $('userDropdown').classList.remove('show');
  });
  
  $('btnLogout').addEventListener('click', handleLogout);
  
  // Add event button
  $('btnAddEvent').addEventListener('click', () => openModal());
  
  // Screenshot button
  $('btnScreenshot').addEventListener('click', startScreenshot);
  
  // Toggle calendar visibility
  $('btnToggleCal').addEventListener('click', () => {
    document.querySelector('.mini-calendar').classList.toggle('hidden');
  });
  
  // Modal buttons
  $('btnCloseModal').addEventListener('click', closeModal);
  $('btnCancel').addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', e => {
    if (e.target === modalOverlay) closeModal();
  });
  
  // Form submit
  $('eventForm').addEventListener('submit', handleSubmit);
  
  // Calendar navigation
  $('btnPrevMonth').addEventListener('click', () => {
    calDate.setMonth(calDate.getMonth() - 1);
    renderCal();
  });
  $('btnNextMonth').addEventListener('click', () => {
    calDate.setMonth(calDate.getMonth() + 1);
    renderCal();
  });
  $('btnToday').addEventListener('click', () => {
    calDate = new Date();
    renderCal();
  });
  
  // Event delegation for days list (clicks)
  daysList.addEventListener('click', handleDaysClick);
  
  // Notification settings
  $('btnSettings').addEventListener('click', () => {
    $('settingsModal').classList.toggle('show');
  });
  
  $('closeSettings').addEventListener('click', () => {
    $('settingsModal').classList.remove('show');
  });
  
  $('notifToggle').addEventListener('change', saveNotificationSettings);
  $('notifMinutes').addEventListener('change', saveNotificationSettings);
  $('notifSound').addEventListener('change', saveNotificationSettings);
  
  $('btnTestNotif').addEventListener('click', testNotification);
  
  // Reminder banner buttons
  $('btnReminderDone').addEventListener('click', dismissReminder);
  $('btnReminderSnooze5').addEventListener('click', () => snoozeReminder(5));
  $('btnReminderSnooze15').addEventListener('click', () => snoozeReminder(15));
  
  // PDF Converter
  setupPdfListeners();
  
  // Drag events
  daysList.addEventListener('dragstart', handleDragStart);
  daysList.addEventListener('dragend', handleDragEnd);
  daysList.addEventListener('dragover', handleDragOver);
  daysList.addEventListener('dragleave', handleDragLeave);
  daysList.addEventListener('drop', handleDrop);
  
  // Calendar click and tooltip
  const calGrid = $('calGrid');
  calGrid.addEventListener('click', handleCalClick);
  calGrid.addEventListener('pointerenter', handleCalHover, true);
  calGrid.addEventListener('pointerleave', handleCalLeave, true);
}

// Handle calendar day hover (tooltip)
let currentTooltipDay = null;
let lastCalClick = { date: null, time: 0 };

function handleCalHover(e) {
  const day = e.target.closest('.cal-day');
  if (!day || day === currentTooltipDay) return;
  
  currentTooltipDay = day;
  
  const count = parseInt(day.dataset.count) || 0;
  if (count === 0) return;
  
  const tip = day.dataset.tip || '';
  if (!tip) return;
  
  const items = tip.split('||').filter(t => t);
  if (items.length === 0) return;
  
  const tooltip = $('calTip');
  tooltip.innerHTML = items.map(item => `<div class="tip-item">${esc(item)}</div>`).join('');
  
  const rect = day.getBoundingClientRect();
  tooltip.style.left = (rect.left + rect.width / 2) + 'px';
  tooltip.style.top = (rect.top - 8) + 'px';
  tooltip.style.transform = 'translate(-50%, -100%)';
  tooltip.classList.add('show');
}

function handleCalLeave(e) {
  const day = e.target.closest('.cal-day');
  if (!day) return;
  currentTooltipDay = null;
  $('calTip').classList.remove('show');
}

function handleCalClick(e) {
  const day = e.target.closest('.cal-day');
  if (!day) return;
  
  const targetDate = day.dataset.date;
  const now = Date.now();
  
  // Check for double click (within 300ms on same date)
  if (lastCalClick.date === targetDate && now - lastCalClick.time < 300) {
    // Double click - open modal to add event
    lastCalClick = { date: null, time: 0 };
    openModal(null, targetDate);
  } else {
    // Single click - navigate to the day
    lastCalClick = { date: targetDate, time: now };
    navigateToDate(targetDate);
  }
}

// Navigate to a specific date in the days list
function navigateToDate(targetDate) {
  const target = new Date(targetDate + 'T00:00:00');
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const rangeStart = new Date(viewStartDate);
  rangeStart.setHours(0, 0, 0, 0);
  const rangeEnd = new Date(rangeStart);
  rangeEnd.setDate(rangeEnd.getDate() + VISIBLE_DAYS);
  
  const isInRange = target >= rangeStart && target < rangeEnd;
  
  if (!isInRange) {
    // Set view start to show the target date
    // For past dates, start from the target date itself
    // For future dates, start a few days before
    viewStartDate = new Date(target);
    if (target >= today) {
      viewStartDate.setDate(viewStartDate.getDate() - 3);
    }
    viewStartDate.setHours(0, 0, 0, 0);
    
    renderDays();
  }
  
  document.querySelectorAll('.day-row.highlighted').forEach(el => {
    el.classList.remove('highlighted');
  });
  
  // Calculate if this day is in the "open by default" range
  const daysFromToday = Math.floor((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  const isOpenByDefault = daysFromToday >= 0 && daysFromToday <= 2;
  
  // Expand the day we're navigating to
  if (isOpenByDefault) {
    // For days open by default, remove from collapsed if present
    if (collapsed.has(targetDate)) {
      collapsed.delete(targetDate);
      renderDays();
    }
  } else {
    // For days collapsed by default, add to manuallyExpanded
    if (!manuallyExpanded.has(targetDate)) {
      manuallyExpanded.add(targetDate);
      renderDays();
    }
  }
  
  setTimeout(() => {
    const dayRow = document.querySelector(`.day-row[data-date="${targetDate}"]`);
    if (dayRow) {
      dayRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
      dayRow.classList.add('highlighted');
      
      setTimeout(() => {
        dayRow.classList.remove('highlighted');
      }, 2000);
    }
  }, 100);
}

function handleDaysClick(e) {
  const expandBtn = e.target.closest('.btn-expand');
  if (expandBtn) {
    const evtId = expandBtn.dataset.id;
    if (expandedEvents.has(evtId)) {
      expandedEvents.delete(evtId);
    } else {
      expandedEvents.add(evtId);
    }
    renderDays();
    return;
  }
  
  const completeBtn = e.target.closest('.btn-complete');
  if (completeBtn) {
    toggleCompleted(completeBtn.dataset.id);
    return;
  }
  
  const dayHeader = e.target.closest('.day-header');
  if (dayHeader) {
    const dayRow = dayHeader.closest('.day-row');
    const dateKey = dayRow.dataset.date;
    
    // Determine if this day is in the "open by default" range (today + 2 days)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dateObj = new Date(dateKey + 'T00:00:00');
    const daysFromToday = Math.floor((dateObj.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    const isOpenByDefault = daysFromToday >= 0 && daysFromToday <= 2;
    
    if (isOpenByDefault) {
      // For days that are open by default: use collapsed set
      if (collapsed.has(dateKey)) {
        collapsed.delete(dateKey);
      } else {
        collapsed.add(dateKey);
      }
    } else {
      // For days that are collapsed by default: use manuallyExpanded set
      if (manuallyExpanded.has(dateKey)) {
        manuallyExpanded.delete(dateKey);
      } else {
        manuallyExpanded.add(dateKey);
      }
    }
    renderDays();
    return;
  }
  
  const editBtn = e.target.closest('.btn-edit');
  if (editBtn) {
    openModal(editBtn.dataset.id);
    return;
  }
  
  const delBtn = e.target.closest('.btn-del');
  if (delBtn) {
    deleteEvent(delBtn.dataset.id);
    return;
  }
}

async function toggleCompleted(id) {
  let evt = null;
  let evtDate = null;
  for (const d in events) {
    const found = events[d].find(e => e.id === id);
    if (found) { evt = found; evtDate = d; break; }
  }
  
  if (!evt) return;
  
  const newStatus = !evt.completed;
  
  try {
    setStatus('sync', 'Actualizando...');
    await api('PATCH', { completed: newStatus }, `?id=eq.${id}`);
    evt.completed = newStatus;
    setStatus('ok', 'Sincronizado');
    renderDays();
    renderCal();
    
    // Re-schedule notifications (excludes completed events)
    scheduleNotifications();
    
    showToast(newStatus ? 'Tarea completada' : 'Tarea pendiente');
  } catch (err) {
    console.error(err);
    setStatus('err', 'Error');
    showToast('Error al actualizar');
  }
}

// Drag & Drop
function handleDragStart(e) {
  const row = e.target.closest('.event-row');
  if (!row) return;
  dragId = row.dataset.id;
  dragDate = row.dataset.date;
  row.classList.add('dragging');
  e.dataTransfer.effectAllowed = 'move';
}

function handleDragEnd(e) {
  const row = e.target.closest('.event-row');
  if (row) row.classList.remove('dragging');
  document.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
  dragId = null;
  dragDate = null;
}

function handleDragOver(e) {
  e.preventDefault();
  const dayRow = e.target.closest('.day-row');
  if (dayRow) dayRow.classList.add('drag-over');
}

function handleDragLeave(e) {
  const dayRow = e.target.closest('.day-row');
  if (dayRow) dayRow.classList.remove('drag-over');
}

async function handleDrop(e) {
  e.preventDefault();
  const dayRow = e.target.closest('.day-row');
  if (!dayRow) return;
  
  dayRow.classList.remove('drag-over');
  const newDate = dayRow.dataset.date;
  
  if (!dragId || !dragDate || dragDate === newDate) return;
  
  try {
    setStatus('sync', 'Moviendo...');
    await api('PATCH', { date: newDate }, `?id=eq.${dragId}`);
    
    const oldList = events[dragDate] || [];
    const idx = oldList.findIndex(ev => ev.id === dragId);
    if (idx !== -1) {
      const [evt] = oldList.splice(idx, 1);
      evt.date = newDate;
      if (!events[newDate]) events[newDate] = [];
      events[newDate].push(evt);
      if (oldList.length === 0) delete events[dragDate];
    }
    
    setStatus('ok', 'Sincronizado');
    renderDays();
    renderCal();
    showToast('Evento movido');
  } catch (err) {
    console.error(err);
    setStatus('err', 'Error');
    showToast('Error al mover');
  }
}

// Render Days List
function renderDays() {
  const dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
                       'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  let html = '';
  
  for (let i = 0; i < VISIBLE_DAYS; i++) {
    const date = new Date(viewStartDate);
    date.setDate(date.getDate() + i);
    const key = fmtDate(date);
    const list = events[key] || [];
    const isToday = date.getTime() === today.getTime();
    
    // Calculate days from today (0 = today, 1 = tomorrow, etc.)
    const daysFromToday = Math.floor((date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    const isOpenByDefault = daysFromToday >= 0 && daysFromToday <= 2;
    
    // Logic: Today + next 2 days are open by default (user can collapse them)
    // Other days are collapsed by default (user can expand them via manuallyExpanded)
    let isCol;
    if (isOpenByDefault) {
      isCol = collapsed.has(key);
    } else {
      isCol = !manuallyExpanded.has(key);
    }
    
    html += `
      <div class="day-row ${isToday ? 'today' : ''} ${isCol ? 'collapsed' : ''} ${list.length === 0 ? 'no-events' : ''}" data-date="${key}">
        <div class="day-header">
          <div class="day-date">
            <div class="day-name">${isToday ? 'HOY' : dayNames[date.getDay()]}</div>
            <div class="day-num">${date.getDate()} ${monthNames[date.getMonth()]}</div>
          </div>
          <div class="day-info">
            <span class="day-count">${list.length} evento${list.length !== 1 ? 's' : ''}</span>
            <div class="day-dots">
              ${list.slice(0, 4).map(ev => `<span class="day-dot ${ev.completed ? 'completed' : ''}" style="background:${ev.completed ? '#86efac' : ev.color}"></span>`).join('')}
            </div>
          </div>
          <div class="day-toggle">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>
        <div class="day-events">
          ${list.length > 0 ? list.map(ev => {
            const isExpanded = expandedEvents.has(ev.id);
            const isOwn = ev.user_id === currentUser.id;
            const publicBadge = ev.is_public ? '<span class="event-public">🌍 Público</span>' : '';
            const authorName = !isOwn && ev.user_name ? `<span class="event-author">por ${esc(ev.user_name)}</span>` : '';
            return `
            <div class="event-row ${ev.completed ? 'completed' : ''} ${!isOwn ? 'shared-event' : ''}" draggable="${isOwn}" data-id="${ev.id}" data-date="${ev.date}">
              <span class="event-color ${ev.completed ? 'completed' : ''}" style="background:${ev.completed ? '#86efac' : ev.color}"></span>
              <div class="event-content">
                <div class="event-title">${ev.completed ? '✓ ' : ''}${esc(ev.title)}${publicBadge}${authorName}</div>
                ${ev.time ? `<div class="event-time">${fmtTime(ev.time)}</div>` : ''}
                ${isExpanded && ev.description ? `<div class="event-details">${esc(ev.description)}</div>` : ''}
              </div>
              <div class="event-btns">
                <button class="evt-btn btn-expand" data-id="${ev.id}" title="${isExpanded ? 'Ocultar detalles' : 'Ver detalles'}">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="transform: ${isExpanded ? 'rotate(180deg)' : 'rotate(0)'}">
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </button>
                ${isOwn ? `
                <button class="evt-btn btn-complete" data-id="${ev.id}" title="${ev.completed ? 'Desmarcar' : 'Completar'}">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </button>
                <button class="evt-btn btn-edit" data-id="${ev.id}" title="Editar">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                  </svg>
                </button>
                <button class="evt-btn del btn-del" data-id="${ev.id}" title="Eliminar">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                  </svg>
                </button>
                ` : ''}
              </div>
            </div>
          `}).join('') : '<div class="no-events">Sin eventos</div>'}
        </div>
      </div>
    `;
  }
  
  daysList.innerHTML = html;
}

// Render Mini Calendar
function renderCal() {
  const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
                       'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  
  $('calMonth').textContent = `${monthNames[calDate.getMonth()]} ${calDate.getFullYear()}`;
  
  const year = calDate.getFullYear();
  const month = calDate.getMonth();
  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  
  let start = first.getDay();
  start = start === 0 ? 6 : start - 1;
  
  const days = last.getDate();
  const prev = new Date(year, month, 0).getDate();
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  let html = '';
  
  // Prev month days
  for (let i = start - 1; i >= 0; i--) {
    const d = prev - i;
    const dt = new Date(year, month - 1, d);
    const key = fmtDate(dt);
    const evts = events[key] || [];
    const tooltip = evts.map(e => `${e.completed ? '✓ ' : ''}${e.time ? fmtTime(e.time)+' ' : ''}${e.title}`).join('||');
    html += `<div class="cal-day other ${evts.length === 0 ? 'empty' : ''}" data-date="${key}" data-tip="${esc(tooltip)}" data-count="${evts.length}">${d}
      <div class="cal-dots">${evts.slice(0, 3).map(e => `<span class="cal-dot ${e.completed ? 'completed' : ''}" style="background:${e.completed ? '#86efac' : e.color}"></span>`).join('')}</div>
    </div>`;
  }
  
  // Current month
  for (let d = 1; d <= days; d++) {
    const dt = new Date(year, month, d);
    const key = fmtDate(dt);
    const evts = events[key] || [];
    const isToday = dt.getTime() === today.getTime();
    const tooltip = evts.map(e => `${e.completed ? '✓ ' : ''}${e.time ? fmtTime(e.time)+' ' : ''}${e.title}`).join('||');
    html += `<div class="cal-day ${isToday ? 'today' : ''} ${evts.length === 0 ? 'empty' : ''}" data-date="${key}" data-tip="${esc(tooltip)}" data-count="${evts.length}">${d}
      <div class="cal-dots">${evts.slice(0, 3).map(e => `<span class="cal-dot ${e.completed ? 'completed' : ''}" style="background:${e.completed ? '#86efac' : e.color}"></span>`).join('')}</div>
    </div>`;
  }
  
  // Next month
  const rem = 42 - (start + days);
  for (let d = 1; d <= rem; d++) {
    const dt = new Date(year, month + 1, d);
    const key = fmtDate(dt);
    const evts = events[key] || [];
    const tooltip = evts.map(e => `${e.completed ? '✓ ' : ''}${e.time ? fmtTime(e.time)+' ' : ''}${e.title}`).join('||');
    html += `<div class="cal-day other ${evts.length === 0 ? 'empty' : ''}" data-date="${key}" data-tip="${esc(tooltip)}" data-count="${evts.length}">${d}
      <div class="cal-dots">${evts.slice(0, 3).map(e => `<span class="cal-dot ${e.completed ? 'completed' : ''}" style="background:${e.completed ? '#86efac' : e.color}"></span>`).join('')}</div>
    </div>`;
  }
  
  $('calGrid').innerHTML = html;
}

// Modal
function openModal(id = null, date = null) {
  editingId = id;
  
  if (id) {
    let evt = null;
    for (const d in events) {
      const found = events[d].find(e => e.id === id);
      if (found) { evt = found; break; }
    }
    
    if (evt) {
      $('modalTitle').textContent = 'Editar Evento';
      $('inputTitle').value = evt.title;
      $('inputDate').value = evt.date;
      $('inputTime').value = evt.time || '';
      $('inputDesc').value = evt.description || '';
      $('inputPublic').checked = evt.is_public || false;
      
      const radio = document.querySelector(`input[name="color"][value="${evt.color}"]`);
      if (radio) radio.checked = true;
    }
  } else {
    $('modalTitle').textContent = 'Nuevo Evento';
    $('inputTitle').value = '';
    $('inputDate').value = date || fmtDate(new Date());
    $('inputTime').value = '';
    $('inputDesc').value = '';
    $('inputPublic').checked = false;
    $('c1').checked = true;
  }
  
  modalOverlay.classList.add('show');
  $('inputTitle').focus();
}

function closeModal() {
  modalOverlay.classList.remove('show');
  editingId = null;
}

// Handle form submit
async function handleSubmit(e) {
  e.preventDefault();
  
  const title = $('inputTitle').value.trim();
  const date = $('inputDate').value;
  const time = $('inputTime').value;
  const desc = $('inputDesc').value.trim();
  const color = document.querySelector('input[name="color"]:checked').value;
  const isPublic = $('inputPublic').checked;
  
  if (!title || !date) {
    showToast('Título y fecha requeridos');
    return;
  }
  
  try {
    setStatus('sync', 'Guardando...');
    
    if (editingId) {
      let oldDate = null;
      let oldCompleted = false;
      for (const d in events) {
        const found = events[d].find(e => e.id === editingId);
        if (found) { oldDate = d; oldCompleted = found.completed; break; }
      }
      
      await api('PATCH', { title, date, time: time || null, description: desc || null, color, is_public: isPublic, user_name: currentUser.name }, `?id=eq.${editingId}`);
      
      if (oldDate) {
        events[oldDate] = events[oldDate].filter(e => e.id !== editingId);
        if (events[oldDate].length === 0) delete events[oldDate];
      }
      if (!events[date]) events[date] = [];
      events[date].push({ id: editingId, title, date, time, description: desc, color, completed: oldCompleted, is_public: isPublic, user_id: currentUser.id, user_name: currentUser.name });
      
      showToast('Evento actualizado');
    } else {
      if (!currentUser || !currentUser.id) {
        throw new Error('Usuario no identificado. Por favor, recarga la página.');
      }
      const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
      console.log('Creating event with user_id:', currentUser.id);
      await api('POST', { id, title, date, time: time || null, description: desc || null, color, completed: false, user_id: currentUser.id, user_name: currentUser.name, is_public: isPublic });
      
      if (!events[date]) events[date] = [];
      events[date].push({ id, title, date, time, description: desc, color, completed: false, is_public: isPublic, user_id: currentUser.id, user_name: currentUser.name });
      
      showToast('Evento creado');
    }
    
    setStatus('ok', 'Sincronizado');
    closeModal();
    renderDays();
    renderCal();
    
    // Schedule notifications for upcoming events
    scheduleNotifications();
  } catch (err) {
    console.error('Error al guardar evento:', err);
    setStatus('err', 'Error');
    showToast('Error: ' + (err.message || 'Error al guardar'));
  }
}

// Delete
async function deleteEvent(id) {
  if (!confirm('¿Eliminar este evento?')) return;
  
  try {
    setStatus('sync', 'Eliminando...');
    await api('DELETE', null, `?id=eq.${id}`);
    
    for (const d in events) {
      events[d] = events[d].filter(e => e.id !== id);
      if (events[d].length === 0) delete events[d];
    }
    
    setStatus('ok', 'Sincronizado');
    renderDays();
    renderCal();
    showToast('Evento eliminado');
  } catch (err) {
    console.error(err);
    setStatus('err', 'Error');
    showToast('Error al eliminar');
  }
}

// Load Events
async function loadEvents() {
  if (!session || !currentUser) {
    console.log('No session, skipping load');
    return;
  }
  
  try {
    setStatus('sync', 'Cargando...');
    
    // Load events: own events OR public events from others
    const query = `?select=*&or=(user_id.eq.${currentUser.id},is_public.eq.true)&order=date.asc&order=time.asc`;
    const data = await api('GET', null, query);
    
    events = {};
    const eventsList = [];
    
    if (data && data.length > 0) {
      data.forEach(ev => {
        if (!events[ev.date]) events[ev.date] = [];
        events[ev.date].push({
          id: ev.id,
          title: ev.title,
          date: ev.date,
          time: ev.time,
          description: ev.description,
          color: ev.color,
          completed: ev.completed || false,
          is_public: ev.is_public || false,
          user_id: ev.user_id,
          user_name: ev.user_name && ev.user_name !== 'Usuario' ? ev.user_name : null
        });
        
        // Add to flat list for notifications (only own events with time AND NOT completed)
        if (ev.user_id === currentUser.id && ev.time && !ev.completed) {
          eventsList.push(ev);
        }
      });
    }
    
    setStatus('ok', 'Sincronizado');
    renderDays();
    renderCal();
    
    // Schedule notifications for upcoming events (excludes completed)
    scheduleNotifications(eventsList);
  } catch (err) {
    console.error('Load error:', err);
    setStatus('err', 'Error');
    showToast('Error de conexión: ' + err.message);
    
    if (err.message.includes('expirada') || err.message.includes('401') || err.message.includes('403')) {
      handleLogout();
    }
  }
}

// Schedule notifications - ONLY for events that are NOT completed
function scheduleNotifications(eventsList) {
  if (!eventsList) {
    // Build events list from current events (exclude completed)
    eventsList = [];
    for (const date in events) {
      events[date].forEach(ev => {
        // Only include own events with time AND NOT completed
        if (ev.user_id === currentUser?.id && ev.time && !ev.completed) {
          eventsList.push(ev);
        }
      });
    }
  }
  
  chrome.runtime.sendMessage({
    type: 'SCHEDULE_NOTIFICATIONS',
    events: eventsList
  });
}

// Test notification
function testNotification() {
  chrome.runtime.sendMessage({
    type: 'TEST_NOTIFICATION',
    title: 'Prueba de notificación 📅'
  });
  showToast('Notificación de prueba enviada');
}

// Show reminder banner
function showReminderBanner(event) {
  currentReminder = event;
  const banner = $('reminderBanner');
  
  $('reminderTitle').textContent = event.title;
  $('reminderTime').textContent = event.time ? fmtTime(event.time) : '';
  
  banner.classList.add('show');
}

// Dismiss reminder
function dismissReminder() {
  $('reminderBanner').classList.remove('show');
  currentReminder = null;
}

// Snooze reminder
function snoozeReminder(minutes) {
  if (currentReminder) {
    chrome.runtime.sendMessage({
      type: 'SCHEDULE_NOTIFICATIONS',
      events: [{
        ...currentReminder,
        id: `snooze_${Date.now()}`
      }]
    });
    showToast(`Recordatorio pospuesto ${minutes} minutos`);
  }
  dismissReminder();
}

// ============================================
// PDF TOOLS
// ============================================

function setupPdfListeners() {
  // Open PDF modal
  $('btnPdf').addEventListener('click', openPdfModal);
  $('closePdfModal').addEventListener('click', closePdfModal);
  
  // Tab switching
  document.querySelectorAll('.pdf-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.pdf-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.pdf-tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      const tabId = tab.dataset.tab + 'Tab';
      $(tabId).classList.add('active');
    });
  });
  
  // Tab 1: Image to PDF
  $('pdfDropzone').addEventListener('click', () => $('pdfFileInput').click());
  $('pdfFileInput').addEventListener('change', handlePdfFileSelect);
  $('pdfDropzone').addEventListener('dragover', handlePdfDragOver);
  $('pdfDropzone').addEventListener('dragleave', handlePdfDragLeave);
  $('pdfDropzone').addEventListener('drop', handlePdfDrop);
  $('pdfClearBtn').addEventListener('click', clearPdfFiles);
  $('btnPortrait').addEventListener('click', () => selectOrientation('portrait'));
  $('btnLandscape').addEventListener('click', () => selectOrientation('landscape'));
  $('btnConvertPdf').addEventListener('click', convertToPdf);
  
  // Tab 2: Merge PDFs
  $('mergeDropzone').addEventListener('click', () => $('mergeFileInput').click());
  $('mergeFileInput').addEventListener('change', handleMergeFileSelect);
  $('mergeDropzone').addEventListener('dragover', handleMergeDragOver);
  $('mergeDropzone').addEventListener('dragleave', handleMergeDragLeave);
  $('mergeDropzone').addEventListener('drop', handleMergeDrop);
  $('mergeClearBtn').addEventListener('click', clearMergeFiles);
  $('btnMergePdf').addEventListener('click', mergePdfsAction);
  
  // Tab 3: Split PDF
  $('splitDropzone').addEventListener('click', () => $('splitFileInput').click());
  $('splitFileInput').addEventListener('change', handleSplitFileSelect);
  $('splitDropzone').addEventListener('dragover', handleSplitDragOver);
  $('splitDropzone').addEventListener('dragleave', handleSplitDragLeave);
  $('splitDropzone').addEventListener('drop', handleSplitDrop);
  $('splitClearBtn').addEventListener('click', clearSplitFile);
  $('btnSplitPdf').addEventListener('click', splitPdfAction);
}

function openPdfModal() {
  $('pdfModal').classList.add('show');
}

function closePdfModal() {
  $('pdfModal').classList.remove('show');
}

// Image to PDF functions
function handlePdfDragOver(e) {
  e.preventDefault();
  $('pdfDropzone').classList.add('drag-over');
}

function handlePdfDragLeave(e) {
  $('pdfDropzone').classList.remove('drag-over');
}

function handlePdfDrop(e) {
  e.preventDefault();
  $('pdfDropzone').classList.remove('drag-over');
  const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
  if (files.length > 0) {
    addPdfImages(files);
  }
}

function handlePdfFileSelect(e) {
  const files = Array.from(e.target.files);
  if (files.length > 0) {
    addPdfImages(files);
  }
}

async function addPdfImages(files) {
  for (const file of files) {
    const reader = new FileReader();
    const dataUrl = await new Promise((resolve, reject) => {
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
    pdfImages.push({ name: file.name, dataUrl });
  }
  renderPdfPreview();
}

function renderPdfPreview() {
  if (pdfImages.length === 0) {
    $('pdfPreviewArea').style.display = 'none';
    return;
  }
  
  $('pdfPreviewArea').style.display = 'block';
  $('pdfPreviewList').innerHTML = pdfImages.map((img, i) => `
    <div class="pdf-preview-item">
      <img src="${img.dataUrl}" alt="${img.name}">
      <span class="pdf-preview-name">${img.name}</span>
      <button class="pdf-remove-btn" data-index="${i}">✕</button>
    </div>
  `).join('');
  
  // Add remove listeners
  document.querySelectorAll('.pdf-remove-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const index = parseInt(e.target.dataset.index);
      pdfImages.splice(index, 1);
      renderPdfPreview();
    });
  });
}

function clearPdfFiles() {
  pdfImages = [];
  $('pdfPreviewArea').style.display = 'none';
  $('pdfFileInput').value = '';
}

function selectOrientation(orient) {
  pdfOrientation = orient;
  document.querySelectorAll('.pdf-option-btn').forEach(btn => btn.classList.remove('active'));
  $(orient === 'portrait' ? 'btnPortrait' : 'btnLandscape').classList.add('active');
}

async function convertToPdf() {
  if (pdfImages.length === 0) {
    showToast('Añade al menos una imagen');
    return;
  }
  
  const btn = $('btnConvertPdf');
  btn.disabled = true;
  btn.querySelector('.btn-text').textContent = 'Convirtiendo...';
  btn.querySelector('.btn-loader').style.display = 'block';
  
  try {
    const { jsPDF } = window.jspdf;
    const pageSize = $('pdfPageSize').value;
    
    // Determine orientation and size
    let orientation = pdfOrientation;
    let pageWidth, pageHeight;
    
    switch (pageSize) {
      case 'a4':
        pageWidth = orientation === 'portrait' ? 210 : 297;
        pageHeight = orientation === 'portrait' ? 297 : 210;
        break;
      case 'letter':
        pageWidth = orientation === 'portrait' ? 215.9 : 279.4;
        pageHeight = orientation === 'portrait' ? 279.4 : 215.9;
        break;
      case 'legal':
        pageWidth = orientation === 'portrait' ? 215.9 : 355.6;
        pageHeight = orientation === 'portrait' ? 355.6 : 215.9;
        break;
      case 'fit':
        // Will be determined per image
        break;
    }
    
    const pdf = new jsPDF({
      orientation: pageSize === 'fit' ? 'portrait' : orientation,
      unit: 'mm',
      format: pageSize === 'fit' ? 'a4' : pageSize
    });
    
    for (let i = 0; i < pdfImages.length; i++) {
      if (i > 0) pdf.addPage();
      
      const img = pdfImages[i];
      const imgEl = await createImageBitmap(await (await fetch(img.dataUrl)).blob());
      
      if (pageSize === 'fit') {
        // Fit page to image
        const imgWidth = imgEl.width * 0.264583; // px to mm
        const imgHeight = imgEl.height * 0.264583;
        pdf.internal.pageSize.setWidth(imgWidth);
        pdf.internal.pageSize.setHeight(imgHeight);
        pdf.addImage(img.dataUrl, 'JPEG', 0, 0, imgWidth, imgHeight);
      } else {
        // Fit image to page with margins
        const margin = 10;
        const maxWidth = pageWidth - margin * 2;
        const maxHeight = pageHeight - margin * 2;
        
        const imgRatio = imgEl.width / imgEl.height;
        let finalWidth = maxWidth;
        let finalHeight = finalWidth / imgRatio;
        
        if (finalHeight > maxHeight) {
          finalHeight = maxHeight;
          finalWidth = finalHeight * imgRatio;
        }
        
        const x = (pageWidth - finalWidth) / 2;
        const y = (pageHeight - finalHeight) / 2;
        
        pdf.addImage(img.dataUrl, 'JPEG', x, y, finalWidth, finalHeight);
      }
    }
    
    pdf.save('documento.pdf');
    showToast('PDF creado correctamente');
    closePdfModal();
    clearPdfFiles();
    
  } catch (err) {
    console.error('Error creating PDF:', err);
    showToast('Error al crear PDF: ' + err.message);
  } finally {
    btn.disabled = false;
    btn.querySelector('.btn-text').textContent = 'Convertir a PDF →';
    btn.querySelector('.btn-loader').style.display = 'none';
  }
}

// Merge PDFs functions
function handleMergeDragOver(e) {
  e.preventDefault();
  $('mergeDropzone').classList.add('drag-over');
}

function handleMergeDragLeave(e) {
  $('mergeDropzone').classList.remove('drag-over');
}

function handleMergeDrop(e) {
  e.preventDefault();
  $('mergeDropzone').classList.remove('drag-over');
  const files = Array.from(e.dataTransfer.files).filter(f => f.type === 'application/pdf');
  if (files.length > 0) {
    addMergeFiles(files);
  }
}

function handleMergeFileSelect(e) {
  const files = Array.from(e.target.files);
  if (files.length > 0) {
    addMergeFiles(files);
  }
}

async function addMergeFiles(files) {
  for (const file of files) {
    const arrayBuffer = await file.arrayBuffer();
    mergePdfs.push({ name: file.name, data: arrayBuffer });
  }
  renderMergePreview();
}

function renderMergePreview() {
  if (mergePdfs.length === 0) {
    $('mergePreviewArea').style.display = 'none';
    return;
  }
  
  $('mergePreviewArea').style.display = 'block';
  $('mergePreviewList').innerHTML = mergePdfs.map((pdf, i) => `
    <div class="pdf-preview-item" draggable="true" data-index="${i}">
      <span class="pdf-icon">📄</span>
      <span class="pdf-preview-name">${pdf.name}</span>
      <button class="pdf-remove-btn" data-index="${i}">✕</button>
    </div>
  `).join('');
  
  document.querySelectorAll('#mergePreviewList .pdf-remove-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const index = parseInt(e.target.dataset.index);
      mergePdfs.splice(index, 1);
      renderMergePreview();
    });
  });
}

function clearMergeFiles() {
  mergePdfs = [];
  $('mergePreviewArea').style.display = 'none';
  $('mergeFileInput').value = '';
}

async function mergePdfsAction() {
  if (mergePdfs.length < 2) {
    showToast('Añade al menos 2 PDFs para juntar');
    return;
  }
  
  const btn = $('btnMergePdf');
  btn.disabled = true;
  btn.querySelector('.btn-text').textContent = 'Juntando...';
  btn.querySelector('.btn-loader').style.display = 'block';
  
  try {
    // Use pdf-lib from global scope
    const PDFLib = window.PDFLib;
    if (!PDFLib) {
      throw new Error('pdf-lib no está cargado. Recarga la página.');
    }
    
    const mergedPdf = await PDFLib.PDFDocument.create();
    
    for (const pdfFile of mergePdfs) {
      const pdfDoc = await PDFLib.PDFDocument.load(pdfFile.data);
      const pages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
      pages.forEach(page => mergedPdf.addPage(page));
    }
    
    const pdfBytes = await mergedPdf.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'documento_combinado.pdf';
    a.click();
    URL.revokeObjectURL(url);
    
    showToast('PDFs combinados correctamente');
    closePdfModal();
    clearMergeFiles();
    
  } catch (err) {
    console.error('Error merging PDFs:', err);
    showToast('Error: ' + err.message);
  } finally {
    btn.disabled = false;
    btn.querySelector('.btn-text').textContent = 'Juntar PDFs →';
    btn.querySelector('.btn-loader').style.display = 'none';
  }
}

// Split PDF functions
function handleSplitDragOver(e) {
  e.preventDefault();
  $('splitDropzone').classList.add('drag-over');
}

function handleSplitDragLeave(e) {
  $('splitDropzone').classList.remove('drag-over');
}

function handleSplitDrop(e) {
  e.preventDefault();
  $('splitDropzone').classList.remove('drag-over');
  const files = Array.from(e.dataTransfer.files).filter(f => f.type === 'application/pdf');
  if (files.length > 0) {
    setSplitFile(files[0]);
  }
}

function handleSplitFileSelect(e) {
  const files = Array.from(e.target.files);
  if (files.length > 0) {
    setSplitFile(files[0]);
  }
}

async function setSplitFile(file) {
  const arrayBuffer = await file.arrayBuffer();
  splitPdfFile = { name: file.name, data: arrayBuffer };
  
  $('splitPreviewArea').style.display = 'block';
  $('splitFileInfo').innerHTML = `
    <span class="pdf-icon">📄</span>
    <span>${file.name}</span>
  `;
}

function clearSplitFile() {
  splitPdfFile = null;
  $('splitPreviewArea').style.display = 'none';
  $('splitFileInput').value = '';
}

async function splitPdfAction() {
  if (!splitPdfFile) {
    showToast('Selecciona un PDF para separar');
    return;
  }
  
  const btn = $('btnSplitPdf');
  btn.disabled = true;
  btn.querySelector('.btn-text').textContent = 'Separando...';
  btn.querySelector('.btn-loader').style.display = 'block';
  
  try {
    // Use pdf-lib from global scope
    const PDFLib = window.PDFLib;
    if (!PDFLib) {
      throw new Error('pdf-lib no está cargado');
    }
    
    const pdfDoc = await PDFLib.PDFDocument.load(splitPdfFile.data);
    const pageCount = pdfDoc.getPageCount();
    
    showToast(`Separando ${pageCount} páginas en PDFs...`);
    
    for (let i = 0; i < pageCount; i++) {
      const newPdf = await PDFLib.PDFDocument.create();
      const [page] = await newPdf.copyPages(pdfDoc, [i]);
      newPdf.addPage(page);
      
      const pdfBytes = await newPdf.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = `pagina_${i + 1}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    }
    
    showToast(`${pageCount} PDFs creados correctamente`);
    closePdfModal();
    clearSplitFile();
    
  } catch (err) {
    console.error('Error splitting PDF:', err);
    showToast('Error al separar PDF: ' + err.message);
  } finally {
    btn.disabled = false;
    btn.querySelector('.btn-text').textContent = 'Separar en PDFs →';
    btn.querySelector('.btn-loader').style.display = 'none';
  }
}

// ============================================
// SCREENSHOT FUNCTIONALITY
// ============================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SCREENSHOT_RESULT') {
    handleScreenshotResult(message.dataUrl);
    sendResponse({ success: true });
    return true;
  }
  
  if (message.type === 'SCREENSHOT_CANCELLED') {
    $('btnScreenshot').classList.remove('capturing');
    showToast('Captura cancelada');
    sendResponse({ success: true });
    return true;
  }
  
  if (message.type === 'SCREENSHOT_ERROR') {
    $('btnScreenshot').classList.remove('capturing');
    showToast('Error: ' + message.error);
    sendResponse({ success: true });
    return true;
  }
  
  if (message.type === 'SHOW_REMINDER') {
    showReminderBanner(message.event);
    sendResponse({ success: true });
    return true;
  }
});

async function startScreenshot() {
  const btn = $('btnScreenshot');
  btn.classList.add('capturing');
  
  try {
    await chrome.runtime.sendMessage({ type: 'START_SCREENSHOT' });
  } catch (err) {
    console.error('Error starting screenshot:', err);
    btn.classList.remove('capturing');
    showToast('Error al iniciar captura');
  }
}

async function handleScreenshotResult(dataUrl) {
  const btn = $('btnScreenshot');
  btn.classList.remove('capturing');
  
  if (!dataUrl) {
    showToast('Error: No se recibió la imagen');
    return;
  }
  
  try {
    const response = await fetch(dataUrl);
    if (!response.ok) throw new Error('Error convirtiendo datos');
    const blob = await response.blob();
    
    if (!blob || blob.size === 0) throw new Error('Blob vacío');
    
    let clipboardSuccess = false;
    try {
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob })
      ]);
      clipboardSuccess = true;
    } catch (clipErr) {
      console.log('Clipboard no disponible:', clipErr.message);
    }
    
    try {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `captura-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (downloadErr) {
      console.log('Download error:', downloadErr.message);
    }
    
    showToast(clipboardSuccess ? '✅ Captura copiada y descargada' : '✅ Captura descargada');
  } catch (err) {
    console.error('Error processing screenshot:', err);
    showToast('Error al procesar: ' + err.message);
  }
}

// Helpers
function setStatus(type, text) {
  const dot = $('statusDot');
  dot.className = 'status-dot';
  if (type === 'sync') dot.classList.add('sync');
  if (type === 'err') dot.classList.add('err');
  $('statusText').textContent = text;
}

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

function fmtDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function fmtTime(t) {
  if (!t) return '';
  const [h, m] = t.split(':');
  const hr = parseInt(h);
  const ap = hr >= 12 ? 'PM' : 'AM';
  return `${hr % 12 || 12}:${m} ${ap}`;
}

function esc(txt) {
  const div = document.createElement('div');
  div.textContent = txt;
  return div.innerHTML;
}

// Sync every 30s
setInterval(() => {
  if (currentUser && session) {
    loadEvents();
  }
}, 30000);

// Auto-refresh token every 50 minutes
setInterval(async () => {
  if (session && session.refresh_token) {
    const stored = await chrome.storage.local.get(['session']);
    if (stored.session && stored.session.refresh_token) {
      const success = await refreshSession(stored.session.refresh_token);
      if (success) {
        const newStored = await chrome.storage.local.get(['session']);
        session = newStored.session;
        console.log('Token auto-refreshed');
      }
    }
  }
}, 50 * 60 * 1000);
